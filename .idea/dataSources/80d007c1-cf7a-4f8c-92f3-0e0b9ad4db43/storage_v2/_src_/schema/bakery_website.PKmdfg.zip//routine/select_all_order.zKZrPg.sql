create
    definer = root@localhost procedure select_all_order()
begin
	select orders.*, order_detail.product_id, order_detail.order_amount, order_detail.unit_price
    from orders
    inner join order_detail
    on orders.order_id = order_detail.order_id
    group by orders.order_id;
    end;

